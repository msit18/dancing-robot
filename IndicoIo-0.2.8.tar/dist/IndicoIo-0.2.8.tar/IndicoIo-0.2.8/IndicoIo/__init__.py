JSON_HEADERS = {'Content-type': 'application/json', 'Accept': 'text/plain'}

from text.sentiment import political, spam, posneg
from images.fer import fer
from images.features import facial_features
